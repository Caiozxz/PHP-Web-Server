// script.js
function EnviarCartao(tipo) {
    // Adiciona uma animação de clique ao botão
    document.querySelector(`.${tipo}-button`).classList.add('clicked');

    // Obtém os valores dos campos
    var nome = document.getElementById(`${tipo === 'enviar' ? 'nome' : 'nome-saida'}`).value;
    var funcao = document.getElementById(`${tipo === 'enviar' ? 'funcao' : 'funcao-saida'}`).value;
    var turno = document.getElementById(`${tipo === 'enviar' ? 'turno' : 'turno-saida'}`).value;

    // Obtém a hora atual
    var dataAtual = new Date();
    var horarioEnvio = dataAtual.toLocaleTimeString();

    // Monta a mensagem a ser enviada ao webhook
    var mensagem = {
        embeds: [{
            title: `Cartão de ${tipo === 'enviar' ? 'Entrada' : 'Saída'}`,
            description: `**Nome:** ${nome}\n**Função:** ${funcao}\n**Turno:** ${turno}`,
            color: tipo === 'enviar' ? 0x000000 : 0xFF0000, // Cor preta para Entrada, vermelha para Saída
            footer: {
                text: `Enviado em: ${horarioEnvio}`
            }
        }]
    };

    // Substitua a URL do Webhook pelo seu próprio
    var webhookUrl = 'https://discord.com/api/webhooks/1176302069867626516/atlbwYFLKsTRsKOKysdwu3aSL8s9rIoTw7PUurmD_EviJTwg6kcWeNyQvryRHFLG1s4N';

    // Envia a mensagem para o webhook usando Axios
    axios.post(webhookUrl, mensagem)
        .then(function (response) {
            console.log(`Mensagem embed de ${tipo === 'enviar' ? 'Entrada' : 'Saída'} enviada com sucesso:`, response);
        })
        .catch(function (error) {
            console.error('Erro ao enviar a mensagem:', error);
        });
}

// Adiciona a animação de clique
document.querySelectorAll('.enviar-button, .fechar-button').forEach(button => {
    button.addEventListener('click', function () {
        this.classList.add(`${this.classList.contains('enviar-button') ? 'enviar-button' : 'fechar-button'}-${this.classList.contains('enviar-button') ? 'entrada' : 'saida'}-clicked`);
    });
});