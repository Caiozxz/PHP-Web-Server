<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Adiciona uma linha divisória cinza após o título */
        .header {
            position: relative;
            text-align: center;
            margin-top: 10px;
            /* Ajusta a margem superior */
            margin-bottom: 20px;
            /* Ajusta a margem inferior */
        }

        .header:after {
            content: "";
            display: block;
            width: 100%;
            border-bottom: 2px solid #ccc;
            /* Cor cinza da linha divisória */
        }

        body {
            /* Adiciona a imagem de fundo e configurações */
            background: url('lozsantos.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            /* Remove margens padrão */
            padding: 0;
            /* Remove preenchimento padrão */
            font-family: Arial, sans-serif;
            /* Especifica uma fonte de texto genérica */
            color: #000;
            /* Cor do texto */
        }

        /* Modificações na categoria "Bater Cartão" */
        .categoria {
            font-size: 20px;
            /* Tamanho menor para a categoria */
            color: black;
            /* Cor preta */
            margin-bottom: 10px;
            /* Ajusta a margem abaixo da categoria */
        }

        /* Adiciona um espaçamento entre "Nome" e "Função" */
        .nome,
        .funcao,
        .turno {
            margin-bottom: 15px;
        }

        /* Adiciona um retângulo abaixo do nome, função e turno */
        input[type="text"] {
            display: block;
            width: 300px;
            /* Largura do retângulo */
            height: 30px;
            margin-top: 5px;
            /* Ajusta a margem acima do retângulo */
            border-radius: 10px;
            /* Borda arredondada */
            padding: 5px;
            /* Espaçamento interno */
        }

        /* Centraliza e ajusta o tamanho do título principal */
        h1 {
            font-size: 28px;
            /* Tamanho menor para o título */
            margin-bottom: 10px;
            /* Ajusta a margem abaixo do título */
        }

        /* Adiciona a seção "Turnos" */
        .turnos {
            margin-top: 10px;
            /* Ajusta a margem acima da seção "Turnos" */
        }

        /* Adiciona um retângulo abaixo de "Turnos" */
        .turnos input[type="text"] {
            display: block;
            width: 300px;
            /* Largura do retângulo */
            height: 30px;
            margin-top: 5px;
            /* Ajusta a margem acima do retângulo */
            border-radius: 10px;
            /* Borda arredondada */
            padding: 5px;
            /* Espaçamento interno */
        }

        /* Adiciona o botão verde com transição de cor */
        .enviar-button,
        .fechar-button {
            background-color: #45a049;
            /* Cor verde mais clara */
            color: white;
            /* Cor do texto */
            padding: 8px 15px;
            /* Espaçamento interno */
            font-size: 14px;
            /* Tamanho da fonte */
            border: none;
            /* Sem borda */
            border-radius: 5px;
            /* Borda arredondada */
            margin-top: 10px;
            /* Ajusta a margem acima do botão */
            transition: background-color 0.3s ease;
            /* Adiciona a transição de cor */
        }

        /* Altera a cor do botão quando hover (passa o mouse por cima) */
        .enviar-button:hover,
        .fechar-button:hover {
            background-color: #4CAF50;
            /* Cor verde mais escura */
        }

        /* Adiciona a seção "Bater Cartão (Saída)" */
        .categoria-saida {
            margin-top: 20px;
            /* Ajusta a margem acima da seção "Bater Cartão (Saída)" */
            font-size: 20px;
            /* Tamanho menor para a categoria */
            color: black;
            /* Cor preta */
            margin-bottom: 10px;
/* Ajusta a margem abaixo da categoria */
        }

        /* Ajusta o espaçamento entre os elementos e a borda */
        .content {
            margin: 20px;
        }

        /* Aumenta o espaçamento abaixo dos botões */
        .enviar-button,
        .fechar-button {
            margin-bottom: 10px;
        }

        /* Aumenta o espaçamento acima do botão "Fechar Turno" */
        .fechar-button {
            margin-top: 25px;
        }

        /* Ajusta o espaçamento abaixo dos botões */
        .enviar-button,
        .fechar-button {
            margin-bottom: 10px;
        }

        /* Aumenta o espaçamento acima do botão "Fechar Turno" */
        .fechar-button {
            margin-top: 20px;
        }

        /* Aumenta o tamanho da fonte dos botões */
        .enviar-button,
        .fechar-button {
            font-size: 15px;
        }
    </style>
    <title>SGA - Sistema de Gestão</title>
</head>

<body>
    <div class="header">
        <h1>SGA - Sistema de Gestão</h1>
    </div>

    <div class="content">
        <div class="categoria float-left">
            Categoria: Bater Cartão (Entrada)
        </div>

        <div class="nome float-left">
            Nome: <input type="text" id="nome">
        </div>

        <div class="funcao float-left">
            Função: <input type="text" id="funcao">
        </div>
    </div>

    <div class="turnos">
        Turnos: <input type="text" id="turno">
    </div>

    <button class="enviar-button enviar-button-entrada" onclick="EnviarCartao('enviar')">Iniciar Turno</button>

    <div class="categoria-saida float-left">
        Categoria: Bater Cartão (Saída)
    </div>

    <div class="content">
        <div class="nome float-left">
            Nome: <input type="text" id="nome-saida">
        </div>

        <div class="funcao float-left">
            Função: <input type="text" id="funcao-saida">
        </div>
    </div>

    <div class="turnos float-left">
        Turnos: <input type="text" id="turno-saida">
    </div>

    <button class="fechar-button fechar-button-saida" onclick="EnviarCartao('fechar')">Fechar Turno</button>

    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="script.js"></script>
</body>

</html>