
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="icon" href="images/MCRP.png" type="image/png">
    <style>
        body {
            background-image: url('images/lossantos.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            height: 100vh;
        }

        .center-div {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.7);
        }

        .create-account {
            text-align: center;
            margin-top: 10px;
        }
    </style>
    <title>SGA - Space Roleplay</title>
</head>
<body>
    <div class="container">
        <div class="center-div">
            <div class="text-center">
                <img src="images/MCRP.png" alt="Logo" width="150">
                <br>
                <br>
                <h2>SGA - Space Roleplay</h2>
                <h9><strong>Admin Control Working</strong></h9>
                <br>
                <br>
                <form action="validacao.php" method="post">
                    <div class="form-group">
                        <label for="username">Nome do Administrador</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Nickname">
                    </div>
                    <div class="form-group">
                        <label for="password">Senha Administrativa</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Senha Admin">
                    </div>
                    <button type="submit" class="btn btn-primary">Logar</button>
                    <a href="criar_conta.php" class="btn btn-secondary" style="background-color: gray;">Criar Conta</a>
                </form>
                <p><a href="#">Perdi a senha</a></p>
            </div>
        </div>
    </div>

    <footer class="text-center">
        © <strong> Space Roleplay - 2023</strong>
    </footer>

    <script src="js/jquery-3.5.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
