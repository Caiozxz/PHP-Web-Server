<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se todas as informações necessárias foram fornecidas
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $nomeUsuario = $_POST["username"];
        $senhaUsuario = $_POST["password"];

        // Armazena as informações do usuário em um arquivo CSV
        $linha = $nomeUsuario . "," . $senhaUsuario . "\n";
        file_put_contents("usuarios.csv", $linha, FILE_APPEND);

        // Redireciona o usuário para a página de login após criar a conta
        header("Location: index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="icon" href="images/MCRP.png" type="image/png">
    <style>
        body {
            background-image: url('images/lossantos.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            height: 100vh;
        }

        .center-div {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.7);
        }
    </style>
    <title>SGA - Space Roleplay</title>
</head>
<body>
    <div class="container">
        <div class="center-div">
            <div class="text-center">
                <img src="images/MCRP.png" alt="Logo" width="150">
                <br>
                <br>
                <h2>SGA - Space Roleplay</h2>
                <h9><strong>Admin Control Working</strong></h9>
                <br>
                <br>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <div class="form-group">
                        <label for="username">Nome de usuário</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Nome de usuário">
                    </div>
                    <div class="form-group">
                        <label for="password">Senha</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Senha">
                    </div>
                    <button type="submit" class="btn btn-primary">Criar conta</button>
                </form>
            </div>
        </div>
    </div>

    <footer class="text-center">
        © <strong> Space Roleplay  - 2023</strong>
    </footer>

    <script src="js/jquery-3.5.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
