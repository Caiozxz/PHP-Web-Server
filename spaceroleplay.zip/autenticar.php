<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se todas as informações necessárias foram fornecidas
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $nomeUsuario = $_POST["username"];
        $senhaUsuario = $_POST["password"];

        // Carrega as informações dos usuários do arquivo CSV (ou qualquer outro método de armazenamento que você escolheu)
        $usuarios = file("usuarios.csv", FILE_IGNORE_NEW_LINES);

        // Verifica se as credenciais fornecidas correspondem a um usuário existente
        $credenciaisCorretas = false;
        foreach ($usuarios as $usuario) {
            [$nome, $senha] = explode(",", $usuario);
            if ($nomeUsuario === $nome && $senhaUsuario === $senha) {
                $credenciaisCorretas = true;
                break;
            }
        }

        if ($credenciaisCorretas) {
            // As credenciais estão corretas, redireciona para a página de listagem de turnos
            header("Location: listagemdeturnos.php");
            exit();
        }
    }

    // As credenciais estão incorretas ou não foram fornecidas, redireciona para a página de erro
    header("Location: erro.php");
    exit();
}
?>
